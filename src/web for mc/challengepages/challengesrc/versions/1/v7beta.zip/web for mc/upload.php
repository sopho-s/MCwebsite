<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../Websiteformat.css">
        <title>
            Monthly Challenge upload
        </title>
    </head>
    <body>
        <ul class="menu">
            <li class="menu"><a href="index.html"><button class="menu"><img class="menu" src="home.png"></button></a></li>
        </ul>
        <form action="SourceCode.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="destination" value="/upload.php"/>
            <input type="file" name="file">
            <br>
            <input list="sources" name="sources">
            <datalist>
                <?php
                $dir = "challengepages/challengesrc";
                $files = scandir($dir);
                foreach ($files as $file) {
                    if (strlen($file) > 2 && str_contains($file,'.')) {
                        echo "<option value=\"$file\">";
                    }
                }
                ?>
            </datalist>
            <br>
            <input type="text" name="username" value="Username">
            <input type="text" name="password" value="Password">
            <input type="submit" name="submit">
        </form>
        
    </body>
</html>