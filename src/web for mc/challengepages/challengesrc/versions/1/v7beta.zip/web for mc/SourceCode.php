<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$conn = new mysqli($servername, $username, $password);
$username = $_POST["username"];
$password = $_POST["password"];
$query = "SELECT UserID FROM MC WHERE Username=$username AND Pass=$password";
$result  = $conn->query($query);
if ($result->num_rows > 0) {
    $target_dir = "challengepages/challengesrc/versions/";
    $tempdest = substr($_POST["sources"], 10);
    $dest = substr($tempdest, 0, strlen($tempdest)-7);
    $target_dir = $target_dir . $dest . "/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
}
$path = $_POST["destination"];
header("Location: $path");
?>