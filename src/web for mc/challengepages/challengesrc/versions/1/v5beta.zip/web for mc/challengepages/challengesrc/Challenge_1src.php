<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="/Websiteformat.css">
        <title>
            Monthly Challenge 1 Source Code
        </title>
    </head>
<style>
table, th, td {
  border: 1px solid black;
  padding: 5px;
}
</style>
    <body>
        <ul class="menu">
            <li class="menu"><a href="/index.html"><button class="menu"><img class="menu" src="/challengepages/photos/home.png"></button></a></li>
        </ul>
        <div class="versions">
            <h1>versions</h1>
            <table id="list">
                <tr>
                    <th>File Name</th>
                    <th>Upload Time</th>
                    <th>Upload Size</th>
                </tr>
                <tr>
                <?php
                $dir = "versions/1";
                $files = scandir($dir);
                foreach ($files as $file) {
                    if (strlen($file) > 2) {
                        $uploadtime = date("d F Y H:i:s.", filemtime("versions/1/$file"));
                        $uploadsize = filesize("versions/1/$file") / 1000;
                        $uploadsize = (int) $uploadsize;
                        echo "<tr><td><a href=\"versions/1/$file\" download>$file</a></td><td>$uploadtime</td><td>$uploadsize KB</td></tr>";
                    }
                }
                ?>
                </tr>
            </table>
        </div>
        <script>
            var path = window.location.href;
            document.getElementById("destination").value = path;
        </script>
    </body>
</html>