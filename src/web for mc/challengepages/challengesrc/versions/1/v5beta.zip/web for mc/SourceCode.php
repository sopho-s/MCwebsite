<?php
$target_dir = "versions/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
$path = $_POST["destination"];
header("Location: $path");
?>