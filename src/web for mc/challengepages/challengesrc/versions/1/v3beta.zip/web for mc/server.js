var http = require('http');
var fs = require('fs');

const PORT=8080; 

fs.readFile('./index.html', function (err, html) {

    if (err) throw err;    

    http.createServer(function(request, response) {  
        if(request.url=='/' || request.url=='/index.html'){
            fs.readFile('./index.html', function (err, html) {
                 response.writeHeader(200, {"Content-Type": "text/html"});
                 response.write(html);
                 response.end();
            });
        } else if(request.url=='/Websiteformat.css'){
            fs.readFile('./Websiteformat.css', function (err, cssfile) {
                 response.writeHeader(200, {"Content-Type": "text/css"});
                 response.write(cssfile);
                 response.end();
            });
        } else if(request.url=='/Challenge_1.html'){
            fs.readFile('./Challenge_1.html', function (err, html) {
                 response.writeHeader(200, {"Content-Type": "text/html"});
                 response.write(html);
                 response.end();
            });
        } else if(request.url=='/Challenge_1src.html'){
            fs.readFile('./Challenge_1src.html', function (err, html) {
                 response.writeHeader(200, {"Content-Type": "text/html"});
                 response.write(html);
                 response.end();
            });
        }
    }).listen(PORT);
});