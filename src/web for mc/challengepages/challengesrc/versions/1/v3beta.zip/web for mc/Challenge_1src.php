<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="Websiteformat.css">
        <title>
            Monthly Challenge 1 Source Code
        </title>
    </head>
    <body>
        <ul class="menu">
            <li class="menu"><a href="index.html"><button class="menu"><img class="menu" src="home.png"></button></a></li>
        </ul>
        <form action="SourceCode.php" method="post" enctype="multipart/form-data">
            <input id="destination" type="hidden" name="destination" value=""/>
            <input type="file" name="file" id="file">
            <input type="submit" name="submit">
        </form>
        <div class="versions">
            <h1>versions</h1>
            <ul id="list">
                <?php
                $dir = "versions";
                $files = scandir($dir);
                foreach ($files as $file) {
                    if (strlen($file) > 2) {
                    echo "<li><a href=\"versions/$file\" download>$file</a></li>";
                    }
                }
                ?>
            </ul>
        </div>
        <script>

            var path = window.location.href;
            document.getElementById("destination").value = path;
            
        </script>
    </body>
</html>