<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../Websiteformat.css">
        <title>
            Monthly Challenge upload
        </title>
    </head>
    <body>
        <ul class="menu">
            <li class="menu"><a href="index.html"><button class="menu"><img class="menu" src="challengepages/photos/home.png"></button></a></li>
            <li class="menu"><a href="loginpage.php"><button class="menu"><img class="menu" src="challengepages/photos/login.png"></button></a></li>
        </ul>
        <form action="SourceCode.php" method="post" enctype="multipart/form-data" class="upload">
            <input type="hidden" name="destination" value="/upload.php" class="upload">
            <input type="file" name="file" class="upload">
            <br>
            <input list="sources" name="sources" class="upload">
            <datalist>
                <?php
                $dir = "challengepages/challengesrc";
                $files = scandir($dir);
                foreach ($files as $file) {
                    if (strlen($file) > 2 && str_contains($file,'.')) {
                        echo "<option value=\"$file\">";
                    }
                }
                ?>
            </datalist>
            <input type="submit" name="submit" class="upload">
        </form>
        
    </body>
</html>