<?php
session_start();
if (isset($_SESSION["user"])) {
    if (strlen($_SESSION["user"]) > 0) {
        $path = "user.php";
        header("Location: $path");
    }
} else if (isset($_COOKIE["user"])) {
    if(strlen($_COOKIE["user"]) > 0) {
        $path = "user.php";
        header("Location: $path");
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../Websiteformat.css">
        <title>
            User Login
        </title>
    </head>
    <body>
        <ul class="menu">
            <li class="menu"><a href="index.html"><button class="menu"><img class="menu" src="challengepages/photos/home.png"></button></a></li>
            <li class="menu"><a href="loginpage.php"><button class="menu"><img class="menu" src="challengepages/photos/login.png"></button></a></li>
        </ul>
        <form action="login.php" method="post" enctype="multipart/form-data" class="upload">
            <input type="text" name="username" placeholder="Username" class="upload">
            <input type="text" name="password" placeholder="Password" class="upload">
            <input type="submit" name="submit" class="upload">
        </form>
    </body>
</html>