<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../Websiteformat.css">
        <title>
            <?php
            if (isset($_SESSION["user"])) {
                echo $_SESSION["user"];
            } else if (isset($_COOKIE["user"])) {
                echo $_COOKIE["user"];
            } else {
                $path = "loginpage.php";
                header("Location: $path");
            }
            ?>
        </title>
    </head>
    <body>
        <ul class="menu">
            <li class="menu"><a href="../index.html"><button class="menu"><img class="menu" src="challengepages/photos/home.png"></button></a></li>
            <li class="menu"><a href="../loginpage.php"><button class="menu"><img class="menu" src="challengepages/photos/login.png"></button></a></li>
        </ul>
        <h1 class="user">
            Welcome 
            <?php
            if (isset($_SESSION["user"])) {
                echo $_SESSION["user"];
            } else if (isset($_COOKIE["user"])) {
                echo $_COOKIE["user"];
            } else {
                $path = "loginpage.php";
                header("Location: $path");
            }
            ?>
        </h1>
        <a href="upload.php" class="user"><button>Upload file</button></a>
    </body>
</html>