<?php
session_start();
$servername = "127.0.0.1";
$username = "root";
$password = "";
$conn = new mysqli($servername, $username, $password);
$username = $_POST["username"];
$password = $_POST["password"];
$query = "USE mc";
$result  = $conn->query($query);
$query = "SELECT UserID FROM users WHERE Username=\"$username\" AND Pass=\"$password\"";
$result  = $conn->query($query);
$path = "login.php";
if ($result->num_rows > 0) {
    $path = "user.php";
    setcookie("user", $username, time() + 86400, "/");
    setcookie("password", $password, time() + 86400, "/");
    $_SESSION["user"] = $username;
    $_SESSION["password"] = $password;
}
header("Location: $path");
?>