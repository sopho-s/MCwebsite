<?php
$file = $_POST["file"];
$text = $_POST["text"];
$myfile = fopen("challengepages/markdown/$file.md", "w");
fwrite($myfile, $text);
fclose($myfile);
$path = "challengepages/$file.php";
header("Location: $path");
?>