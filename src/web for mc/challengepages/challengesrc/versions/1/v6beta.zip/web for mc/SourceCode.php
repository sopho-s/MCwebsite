<?php
$target_dir = "challengepages/challengesrc/versions/";
$tempdest = substr($_POST["sources"], 10);
$dest = substr($tempdest, 0, strlen($tempdest)-7);
$target_dir = $target_dir . $dest . "/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
$path = $_POST["destination"];
header("Location: $path");
?>